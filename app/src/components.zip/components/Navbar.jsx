import Logo from "./Logo";
import { Link } from "react-router-dom";
const Navbar = () => {
  return (
    <div className="justify-between flex items-center p-5">
      <div className="flex gap-5 items-center">
        <Link to="/">
          <Logo />
        </Link>
      </div>
      <div className="flex gap-4">
        <div className="flex text-sky-300 font-bold hover:text-sky-200 gap-3">
          <Link to="/register">Register</Link>
        </div>
        <div className="flex text-sky-300 font-bold hover:text-sky-200 gap-3">
          <Link to="/login">Login</Link>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
