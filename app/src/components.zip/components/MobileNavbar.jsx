
const MobileNavbar = () => {
  return (
    <div>
      
    </div>
  )
}

export default MobileNavbar
