// import { VscGitStashApply } from "react-icons/vsc";
import { FaWpforms, FaHistory, FaCalendar } from "react-icons/fa";
import { VscMenu, VscClose } from "react-icons/vsc";
import { useState } from "react";
import { Link } from "react-router-dom";
const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div
      className={`flex relative  ${
        isOpen ? "justify-start" : ""
      } border-none mx-2 h-[90vh]`}
    >
      {isOpen ? (
        <div className=" absolute right-2 top-2">
          <VscClose
            className={`text-2xl cursor-pointer justify-end text-white hover:text-slate-200`}
            onClick={() => setIsOpen(!isOpen)}
          />
        </div>
      ) : (
        <div className="absolute right-5 top-[0.54rem]">
          <VscMenu
            className="text-xl cursor-pointer text-white hover:text-slate-200"
            onClick={() => setIsOpen(!isOpen)}
          />
        </div>
      )}
      <div className="bg-sky-700 p-2 rounded-lg flex m-1 gap-2 items-center flex-col justify-start">
        <Link to='/' className="mt-7 flex w-full hover:bg-sky-600 cursor-pointer rounded-lg p-2 text-sky-100 gap-3 items-center">
          <FaWpforms className="text-xl " />
          <span className={`${isOpen ? "text-sm bold" : "hidden"}`}>Apply</span>
        </Link>
        <Link to='/history' className="flex w-full hover:bg-sky-600 cursor-pointer rounded-lg p-2 text-sky-100 gap-3 items-center">
          <FaHistory className="text-xl " />
          <span className={`${isOpen ? "text-sm bold" : "hidden"}`}>
            History
          </span>
        </Link>
        <Link to='/vacations' className="flex w-full hover:bg-sky-600 cursor-pointer rounded-lg p-2 text-sky-100 gap-3 items-center">
          <FaCalendar className="text-xl " />
          <span className={`${isOpen ? "text-sm bold" : "hidden"}`}>
            Vacations
          </span>
        </Link>
      </div>
    </div>
  );
};

export default Sidebar;
